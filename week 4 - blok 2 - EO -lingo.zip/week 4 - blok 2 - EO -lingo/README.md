week 4 - blok 2 - EO -lingo
